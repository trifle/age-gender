#' @export
#' @importFrom bayestestR simulate_simpson
bayestestR::simulate_simpson

#' @export
#' @importFrom datawizard visualisation_recipe
datawizard::visualisation_recipe
