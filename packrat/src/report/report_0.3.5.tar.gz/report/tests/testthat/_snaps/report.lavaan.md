# model-lavaan detailed report

    Code
      report(model)
    Output
      [1] "Support for lavaan not fully implemented yet :("

# model-lavaan detailed performance

    Code
      report_performance(model)
    Output
      The model is not significantly different from a baseline model (Chi2(8) = 7.98, p = 0.435). The GFI (.97 > .95), AGFI (.91 > .90), NFI (.97 > .90), NNFI (.00 > .90), CFI (.00 > .90), RMSEA (.00 < .05), SRMR (.03 < .08), RFI (.95 > .90), IFI (.00 > .90) and PNFI (.52 > .50) suggest a satisfactory fit.

