# report 0.3.0.9000 (development)

* Added support for models of class `ivreg` (*ivreg*).

# report 0.3.0

* Initial release of the package.
