library(testthat)
library(datawizard)

test_check("datawizard")
