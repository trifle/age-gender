
#' @export
ci.glmmadmb <- ci.tobit
