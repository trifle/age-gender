# classes: .truncreg


#' @export
ci.truncreg <- ci.tobit


#' @export
standard_error.truncreg <- standard_error.default


#' @export
p_value.truncreg <- p_value.default
