#' @importFrom insight n_parameters
#' @export
insight::n_parameters
