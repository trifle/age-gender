
#' @export
ci.lm_robust <- ci.default


#' @export
standard_error.lm_robust <- standard_error.default


#' @export
p_value.lm_robust <- p_value.default
