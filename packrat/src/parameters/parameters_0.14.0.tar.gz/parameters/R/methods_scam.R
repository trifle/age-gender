
#' @export
ci.scam <- ci.gam


#' @export
standard_error.scam <- standard_error.gam


#' @export
p_value.scam <- p_value.gam


#' @export
model_parameters.scam <- model_parameters.cgam
