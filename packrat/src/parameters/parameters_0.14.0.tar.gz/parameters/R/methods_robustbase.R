
#' @export
ci.glmrob <- ci.tobit
