
#' @export
ci.feis <- ci.tobit
